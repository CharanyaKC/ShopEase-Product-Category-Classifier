import re
import nltk
import pandas as pd
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import string

# Download required NLTK data
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')

class SimpleTextPreprocessor:
    def __init__(self):
        self.stop_words = set(stopwords.words('english'))
        self.lemmatizer = WordNetLemmatizer()
        
    def clean_text(self, text):
        """
        Clean and preprocess text data
        """
        if not isinstance(text, str):
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove special characters and numbers
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def remove_stopwords(self, text):
        """
        Remove stopwords from text using simple split
        """
        words = text.split()
        filtered_words = [word for word in words if word.lower() not in self.stop_words]
        return ' '.join(filtered_words)
    
    def lemmatize_text(self, text):
        """
        Lemmatize words in text
        """
        words = text.split()
        lemmatized_words = [self.lemmatizer.lemmatize(word) for word in words]
        return ' '.join(lemmatized_words)
    
    def preprocess(self, text):
        """
        Complete text preprocessing pipeline
        """
        # Clean text
        text = self.clean_text(text)
        
        # Remove stopwords
        text = self.remove_stopwords(text)
        
        # Lemmatize
        text = self.lemmatize_text(text)
        
        return text
    
    def preprocess_batch(self, texts):
        """
        Preprocess a list of texts
        """
        return [self.preprocess(text) for text in texts]

def create_feature_text(product_name, description):
    """
    Combine product name and description into a single feature text
    """
    if pd.isna(product_name):
        product_name = ""
    if pd.isna(description):
        description = ""
    
    return f"{product_name} {description}".strip()

if __name__ == "__main__":
    # Test the preprocessor
    preprocessor = SimpleTextPreprocessor()
    
    test_text = "This is a Premium Smart Phone Product with excellent features!"
    processed = preprocessor.preprocess(test_text)
    print(f"Original: {test_text}")
    print(f"Processed: {processed}") 