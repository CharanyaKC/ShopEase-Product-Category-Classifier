import streamlit as st
import pandas as pd
import joblib
import plotly.express as px
import plotly.graph_objects as go
from text_preprocessor_simple import SimpleTextPreprocessor, create_feature_text
import numpy as np

# Page configuration
st.set_page_config(
    page_title="ShopEase Product Classifier",
    page_icon="🏷️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    .prediction-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin: 1rem 0;
    }
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        border-left: 4px solid #667eea;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def load_model():
    """Load the trained model"""
    try:
        model = joblib.load('product_classifier_model.pkl')
        preprocessor = SimpleTextPreprocessor()
        return model, preprocessor
    except Exception as e:
        st.error(f"Error loading model: {e}")
        return None, None

def predict_category(model, preprocessor, product_name, description):
    """Make prediction for a product"""
    try:
        # Create feature text
        feature_text = create_feature_text(product_name, description)
        
        # Preprocess
        processed_text = preprocessor.preprocess(feature_text)
        
        # Predict
        prediction = model.predict([processed_text])[0]
        probabilities = model.predict_proba([processed_text])[0]
        
        return prediction, probabilities
    except Exception as e:
        st.error(f"Error making prediction: {e}")
        return None, None

def main():
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>🏷️ ShopEase Product Category Classifier</h1>
        <p>AI-powered product categorization for your e-commerce platform</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Load model
    model, preprocessor = load_model()
    
    if model is None:
        st.error("Model not found. Please ensure the model file exists.")
        st.stop()
    
    # Sidebar
    st.sidebar.title("📊 Navigation")
    page = st.sidebar.selectbox(
        "Choose a page",
        ["🏠 Product Classifier", "📈 Model Analytics", "📋 Batch Processing"]
    )
    
    if page == "🏠 Product Classifier":
        show_classifier_page(model, preprocessor)
    elif page == "📈 Model Analytics":
        show_analytics_page()
    elif page == "📋 Batch Processing":
        show_batch_page(model, preprocessor)

def show_classifier_page(model, preprocessor):
    """Main classifier page"""
    st.header("🔍 Product Classification")
    
    # Input form
    col1, col2 = st.columns(2)
    
    with col1:
        product_name = st.text_input(
            "Product Name",
            placeholder="e.g., iPhone 13 Pro, Nike Running Shoes"
        )
    
    with col2:
        description = st.text_area(
            "Product Description",
            placeholder="Describe your product features, specifications, etc.",
            height=100
        )
    
    # Example products
    st.subheader("💡 Try these examples:")
    examples = [
        ("iPhone 13 Pro", "Latest smartphone with advanced camera features and A15 Bionic chip"),
        ("Nike Running Shoes", "Professional running shoes designed for athletes with superior comfort"),
        ("Coffee Table", "Modern wooden coffee table perfect for living room decoration"),
        ("Python Programming Book", "Comprehensive guide to Python programming language"),
        ("Lipstick Set", "Premium makeup collection with various shades and long-lasting formula")
    ]
    
    cols = st.columns(len(examples))
    for i, (name, desc) in enumerate(examples):
        with cols[i]:
            if st.button(f"Try: {name[:15]}...", key=f"example_{i}"):
                st.session_state.product_name = name
                st.session_state.description = desc
                st.rerun()
    
    # Classification button
    if st.button("🚀 Classify Product", type="primary", use_container_width=True):
        if not product_name and not description:
            st.warning("Please provide either a product name or description.")
        else:
            with st.spinner("Analyzing your product..."):
                prediction, probabilities = predict_category(model, preprocessor, product_name, description)
                
                if prediction is not None:
                    # Display results
                    st.markdown(f"""
                    <div class="prediction-card">
                        <h2>Predicted Category: {prediction}</h2>
                        <p>Confidence: {max(probabilities)*100:.1f}%</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Category probabilities
                    st.subheader("📊 Category Probabilities")
                    
                    # Create bar chart
                    categories = [
                        'Electronics', 'Clothing', 'Home & Garden', 'Sports & Outdoors',
                        'Books & Media', 'Beauty & Health', 'Automotive', 'Toys & Games'
                    ]
                    
                    prob_df = pd.DataFrame({
                        'Category': categories,
                        'Probability': probabilities
                    }).sort_values('Probability', ascending=True)
                    
                    fig = px.bar(
                        prob_df, 
                        x='Probability', 
                        y='Category',
                        orientation='h',
                        title="Category Probability Distribution",
                        color='Probability',
                        color_continuous_scale='viridis'
                    )
                    fig.update_layout(height=400)
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Detailed probabilities
                    col1, col2 = st.columns(2)
                    with col1:
                        st.subheader("Top Predictions")
                        for i, (cat, prob) in enumerate(zip(categories, probabilities)):
                            if i < 4:
                                st.markdown(f"""
                                <div class="metric-card">
                                    <strong>{cat}</strong><br>
                                    <span style="color: #667eea;">{prob*100:.1f}%</span>
                                </div>
                                """, unsafe_allow_html=True)
                    
                    with col2:
                        st.subheader("All Categories")
                        for i, (cat, prob) in enumerate(zip(categories, probabilities)):
                            if i >= 4:
                                st.markdown(f"""
                                <div class="metric-card">
                                    <strong>{cat}</strong><br>
                                    <span style="color: #667eea;">{prob*100:.1f}%</span>
                                </div>
                                """, unsafe_allow_html=True)

def show_analytics_page():
    """Model analytics page"""
    st.header("📈 Model Analytics")
    
    # Load sample data if available
    try:
        df = pd.read_csv('product_data.csv')
        
        # Category distribution
        st.subheader("📊 Category Distribution")
        category_counts = df['category'].value_counts()
        
        fig = px.pie(
            values=category_counts.values,
            names=category_counts.index,
            title="Product Categories Distribution"
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Price analysis by category
        st.subheader("💰 Price Analysis by Category")
        fig = px.box(
            df, 
            x='category', 
            y='price',
            title="Price Distribution by Category"
        )
        fig.update_xaxes(tickangle=45)
        st.plotly_chart(fig, use_container_width=True)
        
        # Rating analysis
        st.subheader("⭐ Rating Analysis by Category")
        avg_ratings = df.groupby('category')['rating'].mean().sort_values(ascending=False)
        
        fig = px.bar(
            x=avg_ratings.index,
            y=avg_ratings.values,
            title="Average Rating by Category",
            labels={'x': 'Category', 'y': 'Average Rating'}
        )
        fig.update_xaxes(tickangle=45)
        st.plotly_chart(fig, use_container_width=True)
        
    except FileNotFoundError:
        st.warning("Sample data not found. Please run the data generator first.")

def show_batch_page(model, preprocessor):
    """Batch processing page"""
    st.header("📋 Batch Processing")
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload CSV file with products",
        type=['csv'],
        help="CSV should have 'product_name' and 'description' columns"
    )
    
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            
            if 'product_name' not in df.columns or 'description' not in df.columns:
                st.error("CSV must contain 'product_name' and 'description' columns")
                return
            
            st.success(f"Loaded {len(df)} products")
            
            if st.button("🔍 Process All Products", type="primary"):
                results = []
                
                with st.spinner("Processing products..."):
                    progress_bar = st.progress(0)
                    
                    for i, row in df.iterrows():
                        prediction, probabilities = predict_category(
                            model, preprocessor, 
                            row['product_name'], 
                            row['description']
                        )
                        
                        if prediction is not None:
                            results.append({
                                'product_name': row['product_name'],
                                'description': row['description'],
                                'predicted_category': prediction,
                                'confidence': max(probabilities)
                            })
                        
                        progress_bar.progress((i + 1) / len(df))
                
                # Display results
                results_df = pd.DataFrame(results)
                st.subheader("📊 Batch Processing Results")
                st.dataframe(results_df)
                
                # Download results
                csv = results_df.to_csv(index=False)
                st.download_button(
                    label="📥 Download Results",
                    data=csv,
                    file_name="classification_results.csv",
                    mime="text/csv"
                )
                
                # Summary statistics
                st.subheader("📈 Summary")
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Total Products", len(results_df))
                
                with col2:
                    st.metric("Categories Found", results_df['predicted_category'].nunique())
                
                with col3:
                    avg_confidence = results_df['confidence'].mean()
                    st.metric("Avg Confidence", f"{avg_confidence:.1%}")
        except Exception as e:
            st.error(f"Error processing batch: {e}")

if __name__ == "__main__":
    main() 