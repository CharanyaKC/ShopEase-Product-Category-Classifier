from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd
from text_preprocessor_simple import SimpleTextPreprocessor, create_feature_text
import os

app = Flask(__name__)

# Global variables
classifier = None
preprocessor = None
categories = None

def load_model():
    """Load the trained model"""
    global classifier, preprocessor, categories
    
    try:
        # Load the model
        classifier = joblib.load('product_classifier_model.pkl')
        preprocessor = SimpleTextPreprocessor()
        
        # Define categories (should match training data)
        categories = [
            'Electronics', 'Clothing', 'Home & Garden', 'Sports & Outdoors',
            'Books & Media', 'Beauty & Health', 'Automotive', 'Toys & Games'
        ]
        
        print("Model loaded successfully!")
        return True
    except Exception as e:
        print(f"Error loading model: {e}")
        return False

@app.route('/')
def index():
    """Main page"""
    return render_template('index.html', categories=categories)

@app.route('/predict', methods=['POST'])
def predict():
    """API endpoint for predictions"""
    try:
        data = request.get_json()
        product_name = data.get('product_name', '')
        description = data.get('description', '')
        
        if not product_name and not description:
            return jsonify({'error': 'Please provide product name or description'}), 400
        
        # Create feature text
        feature_text = create_feature_text(product_name, description)
        
        # Preprocess
        processed_text = preprocessor.preprocess(feature_text)
        
        # Predict
        prediction = classifier.predict([processed_text])[0]
        probabilities = classifier.predict_proba([processed_text])[0]
        
        # Create result
        result = {
            'predicted_category': prediction,
            'confidence': float(max(probabilities)),
            'probabilities': dict(zip(categories, probabilities.tolist()))
        }
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'model_loaded': classifier is not None})

if __name__ == '__main__':
    # Load model on startup
    if load_model():
        app.run(debug=True, host='0.0.0.0', port=5000)
    else:
        print("Failed to load model. Please ensure the model file exists.") 