#!/usr/bin/env python3
"""
ShopEase Product Category Classifier - Main Runner Script
This script orchestrates the entire project workflow from data generation to model training.
"""

import os
import sys
import subprocess
import time
from pathlib import Path

def print_banner():
    """Print project banner"""
    print("=" * 60)
    print("🏷️  ShopEase Product Category Classifier")
    print("=" * 60)
    print("AI-powered product categorization for e-commerce platforms")
    print("=" * 60)

def check_dependencies():
    """Check if required dependencies are installed"""
    print("🔍 Checking dependencies...")
    
    required_packages = [
        'numpy', 'pandas', 'scikit-learn', 'matplotlib', 
        'seaborn', 'nltk', 'flask', 'joblib', 'streamlit'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"❌ {package} - Missing")
    
    if missing_packages:
        print(f"\n⚠️  Missing packages: {', '.join(missing_packages)}")
        print("Please install missing packages using:")
        print("pip install -r requirements.txt")
        return False
    
    print("✅ All dependencies are installed!")
    return True

def generate_data():
    """Generate sample training data"""
    print("\n📊 Generating sample training data...")
    
    if os.path.exists('product_data.csv'):
        print("✅ Training data already exists")
        return True
    
    try:
        result = subprocess.run([sys.executable, 'data_generator.py'], 
                              capture_output=True, text=True, check=True)
        print("✅ Sample data generated successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error generating data: {e}")
        print(f"Error output: {e.stderr}")
        return False

def train_model():
    """Train the classification model"""
    print("\n🤖 Training the classification model...")
    
    if os.path.exists('product_classifier_model.pkl'):
        print("✅ Trained model already exists")
        return True
    
    try:
        result = subprocess.run([sys.executable, 'classifier.py'], 
                              capture_output=True, text=True, check=True)
        print("✅ Model trained successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error training model: {e}")
        print(f"Error output: {e.stderr}")
        return False

def start_web_app():
    """Start the Flask web application"""
    print("\n🌐 Starting Flask web application...")
    print("📱 The web app will be available at: http://localhost:5000")
    print("⏹️  Press Ctrl+C to stop the server")
    
    try:
        subprocess.run([sys.executable, 'app.py'])
    except KeyboardInterrupt:
        print("\n🛑 Web server stopped")

def start_streamlit_app():
    """Start the Streamlit application"""
    print("\n📊 Starting Streamlit application...")
    print("📱 The Streamlit app will open in your browser")
    print("⏹️  Press Ctrl+C to stop the server")
    
    try:
        subprocess.run([sys.executable, '-m', 'streamlit', 'run', 'streamlit_app.py'])
    except KeyboardInterrupt:
        print("\n🛑 Streamlit server stopped")

def show_menu():
    """Show the main menu"""
    print("\n" + "=" * 40)
    print("🎯 What would you like to do?")
    print("=" * 40)
    print("1. 🚀 Quick Start (Generate data + Train model)")
    print("2. 📊 Generate Training Data")
    print("3. 🤖 Train Model")
    print("4. 🌐 Start Flask Web App")
    print("5. 📊 Start Streamlit App")
    print("6. 🔧 Test Model (Command Line)")
    print("7. 📋 Show Project Status")
    print("8. 🚪 Exit")
    print("=" * 40)

def test_model():
    """Test the model with sample predictions"""
    print("\n🧪 Testing the model...")
    
    if not os.path.exists('product_classifier_model.pkl'):
        print("❌ Model not found. Please train the model first.")
        return
    
    try:
        from classifier import ProductCategoryClassifier
        
        # Load the model
        classifier = ProductCategoryClassifier()
        classifier.load_model('product_classifier_model.pkl')
        
        # Test predictions
        test_products = [
            ("iPhone 13 Pro", "Latest smartphone with advanced camera features"),
            ("Nike Running Shoes", "Professional running shoes for athletes"),
            ("Coffee Table", "Modern wooden coffee table for living room"),
            ("Python Programming Book", "Comprehensive guide to Python programming"),
            ("Lipstick Set", "Premium makeup collection with various shades")
        ]
        
        print("\n📋 Test Predictions:")
        print("-" * 50)
        
        for product_name, description in test_products:
            result = classifier.predict(product_name, description)
            print(f"Product: {product_name}")
            print(f"Description: {description}")
            print(f"Predicted Category: {result['predicted_category']}")
            print(f"Confidence: {result['confidence']:.2%}")
            print("-" * 50)
            
    except Exception as e:
        print(f"❌ Error testing model: {e}")

def show_status():
    """Show project status"""
    print("\n📋 Project Status:")
    print("-" * 30)
    
    files = [
        ('product_data.csv', 'Training Data'),
        ('product_classifier_model.pkl', 'Trained Model'),
        ('confusion_matrix.png', 'Confusion Matrix'),
        ('templates/index.html', 'Web Template')
    ]
    
    for filename, description in files:
        if os.path.exists(filename):
            size = os.path.getsize(filename)
            print(f"✅ {description}: {filename} ({size:,} bytes)")
        else:
            print(f"❌ {description}: {filename} - Missing")
    
    print("-" * 30)

def quick_start():
    """Quick start workflow"""
    print("\n🚀 Quick Start - Setting up the project...")
    
    # Check dependencies
    if not check_dependencies():
        return False
    
    # Generate data
    if not generate_data():
        return False
    
    # Train model
    if not train_model():
        return False
    
    print("\n✅ Quick start completed successfully!")
    print("🎉 Your ShopEase Product Classifier is ready to use!")
    print("\nNext steps:")
    print("• Run option 4 to start the Flask web app")
    print("• Run option 5 to start the Streamlit app")
    print("• Run option 6 to test the model")
    
    return True

def main():
    """Main function"""
    print_banner()
    
    while True:
        show_menu()
        
        try:
            choice = input("\nEnter your choice (1-8): ").strip()
            
            if choice == '1':
                quick_start()
                
            elif choice == '2':
                if check_dependencies():
                    generate_data()
                    
            elif choice == '3':
                if check_dependencies():
                    if not os.path.exists('product_data.csv'):
                        print("⚠️  No training data found. Generating sample data first...")
                        generate_data()
                    train_model()
                    
            elif choice == '4':
                if not os.path.exists('product_classifier_model.pkl'):
                    print("⚠️  Model not found. Please train the model first (option 3).")
                else:
                    start_web_app()
                    
            elif choice == '5':
                if not os.path.exists('product_classifier_model.pkl'):
                    print("⚠️  Model not found. Please train the model first (option 3).")
                else:
                    start_streamlit_app()
                    
            elif choice == '6':
                test_model()
                
            elif choice == '7':
                show_status()
                
            elif choice == '8':
                print("\n👋 Thank you for using ShopEase Product Classifier!")
                print("Goodbye! 🎉")
                break
                
            else:
                print("❌ Invalid choice. Please enter a number between 1-8.")
                
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"❌ An error occurred: {e}")

if __name__ == "__main__":
    main() 