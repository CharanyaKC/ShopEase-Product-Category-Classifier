import pandas as pd
import numpy as np
import random

def generate_sample_data(num_samples=1000):
    """
    Generate sample product data for training the category classifier
    """
    
    # Define product categories and their associated keywords
    categories = {
        'Electronics': ['phone', 'laptop', 'computer', 'tablet', 'camera', 'headphones', 'speaker', 'tv', 'monitor', 'keyboard', 'mouse', 'gaming', 'wireless', 'bluetooth', 'smart', 'digital', 'electronic', 'tech', 'device', 'gadget'],
        'Clothing': ['shirt', 'dress', 'pants', 'jeans', 'jacket', 'coat', 'sweater', 'hoodie', 't-shirt', 'blouse', 'skirt', 'shorts', 'suit', 'formal', 'casual', 'fashion', 'style', 'wear', 'apparel', 'outfit'],
        'Home & Garden': ['furniture', 'chair', 'table', 'sofa', 'bed', 'lamp', 'plant', 'garden', 'kitchen', 'bathroom', 'decor', 'cushion', 'pillow', 'curtain', 'rug', 'carpet', 'mirror', 'vase', 'flower', 'tool'],
        'Sports & Outdoors': ['bike', 'bicycle', 'running', 'fitness', 'gym', 'exercise', 'sport', 'outdoor', 'camping', 'hiking', 'fishing', 'tennis', 'basketball', 'football', 'soccer', 'swimming', 'yoga', 'training', 'equipment', 'gear'],
        'Books & Media': ['book', 'novel', 'magazine', 'dvd', 'cd', 'movie', 'music', 'audio', 'video', 'game', 'toy', 'puzzle', 'educational', 'fiction', 'non-fiction', 'textbook', 'comic', 'manga', 'art', 'craft'],
        'Beauty & Health': ['makeup', 'cosmetic', 'skincare', 'beauty', 'health', 'vitamin', 'supplement', 'medicine', 'perfume', 'lotion', 'cream', 'shampoo', 'soap', 'brush', 'mirror', 'hair', 'skin', 'care', 'wellness', 'fitness'],
        'Automotive': ['car', 'auto', 'vehicle', 'tire', 'oil', 'battery', 'engine', 'brake', 'filter', 'accessory', 'part', 'tool', 'maintenance', 'repair', 'motorcycle', 'bike', 'truck', 'van', 'suv', 'sedan'],
        'Toys & Games': ['toy', 'game', 'puzzle', 'board', 'card', 'doll', 'action', 'figure', 'building', 'block', 'educational', 'learning', 'fun', 'play', 'entertainment', 'kids', 'children', 'baby', 'infant', 'toddler']
    }
    
    data = []
    
    for _ in range(num_samples):
        # Randomly select a category
        category = random.choice(list(categories.keys()))
        keywords = categories[category]
        
        # Generate product name using category keywords
        num_keywords = random.randint(1, 3)
        selected_keywords = random.sample(keywords, num_keywords)
        
        # Create product name
        if len(selected_keywords) == 1:
            product_name = f"{selected_keywords[0].title()} Product"
        else:
            product_name = f"{' '.join(selected_keywords).title()} Item"
        
        # Add some random words to make it more realistic
        random_words = ['Premium', 'Deluxe', 'Professional', 'Standard', 'Basic', 'Advanced', 'Smart', 'Modern', 'Classic', 'Vintage']
        if random.random() < 0.3:
            product_name = f"{random.choice(random_words)} {product_name}"
        
        # Generate description
        description = f"This is a high-quality {category.lower()} product. {product_name} offers excellent features and durability."
        
        # Generate price
        price = round(random.uniform(10, 500), 2)
        
        # Generate rating
        rating = round(random.uniform(1, 5), 1)
        
        # Generate review count
        review_count = random.randint(0, 1000)
        
        data.append({
            'product_name': product_name,
            'description': description,
            'category': category,
            'price': price,
            'rating': rating,
            'review_count': review_count
        })
    
    return pd.DataFrame(data)

if __name__ == "__main__":
    # Generate sample data
    df = generate_sample_data(1000)
    
    # Save to CSV
    df.to_csv('product_data.csv', index=False)
    print(f"Generated {len(df)} sample products")
    print(f"Categories: {df['category'].value_counts().to_dict()}")
    print("Data saved to 'product_data.csv'") 