import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.pipeline import Pipeline
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from text_preprocessor_simple import SimpleTextPreprocessor, create_feature_text

class ProductCategoryClassifier:
    def __init__(self, model_type='naive_bayes'):
        """
        Initialize the product category classifier
        
        Args:
            model_type (str): Type of model to use ('naive_bayes', 'random_forest', 'svm')
        """
        self.model_type = model_type
        self.preprocessor = SimpleTextPreprocessor()
        self.pipeline = None
        self.vectorizer = None
        self.classifier = None
        self.categories = None
        
    def prepare_data(self, data_path):
        """
        Prepare data for training
        """
        # Load data
        df = pd.read_csv(data_path)
        
        # Create feature text
        df['feature_text'] = df.apply(lambda row: create_feature_text(row['product_name'], row['description']), axis=1)
        
        # Preprocess text
        df['processed_text'] = self.preprocessor.preprocess_batch(df['feature_text'])
        
        # Get categories
        self.categories = df['category'].unique()
        
        return df
    
    def create_pipeline(self):
        """
        Create the ML pipeline
        """
        if self.model_type == 'naive_bayes':
            classifier = MultinomialNB()
        elif self.model_type == 'random_forest':
            classifier = RandomForestClassifier(n_estimators=100, random_state=42)
        elif self.model_type == 'svm':
            classifier = SVC(kernel='linear', probability=True, random_state=42)
        else:
            raise ValueError(f"Unknown model type: {self.model_type}")
        
        self.vectorizer = TfidfVectorizer(
            max_features=5000,
            ngram_range=(1, 2),
            stop_words='english',
            min_df=2,
            max_df=0.95
        )
        
        self.classifier = classifier
        
        self.pipeline = Pipeline([
            ('vectorizer', self.vectorizer),
            ('classifier', self.classifier)
        ])
    
    def train(self, data_path):
        """
        Train the classifier
        """
        print("Loading and preparing data...")
        df = self.prepare_data(data_path)
        
        print("Creating pipeline...")
        self.create_pipeline()
        
        # Split data
        X = df['processed_text']
        y = df['category']
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        print(f"Training {self.model_type} classifier...")
        self.pipeline.fit(X_train, y_train)
        
        # Evaluate
        y_pred = self.pipeline.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        
        print(f"\nModel Performance:")
        print(f"Accuracy: {accuracy:.4f}")
        print("\nClassification Report:")
        print(classification_report(y_test, y_pred))
        
        return X_test, y_test, y_pred
    
    def predict(self, product_name, description):
        """
        Predict category for a single product
        """
        if self.pipeline is None:
            raise ValueError("Model not trained. Please train the model first.")
        
        # Create feature text
        feature_text = create_feature_text(product_name, description)
        
        # Preprocess
        processed_text = self.preprocessor.preprocess(feature_text)
        
        # Predict
        prediction = self.pipeline.predict([processed_text])[0]
        probabilities = self.pipeline.predict_proba([processed_text])[0]
        
        # Create result dictionary
        result = {
            'predicted_category': prediction,
            'confidence': max(probabilities),
            'probabilities': dict(zip(self.categories, probabilities))
        }
        
        return result
    
    def save_model(self, filepath):
        """
        Save the trained model
        """
        if self.pipeline is None:
            raise ValueError("No trained model to save")
        
        joblib.dump(self.pipeline, filepath)
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath):
        """
        Load a trained model
        """
        self.pipeline = joblib.load(filepath)
        self.vectorizer = self.pipeline.named_steps['vectorizer']
        self.classifier = self.pipeline.named_steps['classifier']
        print(f"Model loaded from {filepath}")
    
    def plot_confusion_matrix(self, y_true, y_pred, save_path=None):
        """
        Plot confusion matrix
        """
        cm = confusion_matrix(y_true, y_pred, labels=self.categories)
        
        plt.figure(figsize=(12, 10))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=self.categories, yticklabels=self.categories)
        plt.title('Confusion Matrix')
        plt.xlabel('Predicted')
        plt.ylabel('Actual')
        plt.xticks(rotation=45)
        plt.yticks(rotation=0)
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()

def main():
    """
    Main function to train and evaluate the classifier
    """
    # Initialize classifier
    classifier = ProductCategoryClassifier(model_type='naive_bayes')
    
    # Train the model
    X_test, y_test, y_pred = classifier.train('product_data.csv')
    
    # Save the model
    classifier.save_model('product_classifier_model.pkl')
    
    # Plot confusion matrix
    classifier.plot_confusion_matrix(y_test, y_pred, 'confusion_matrix.png')
    
    # Test predictions
    test_products = [
        ("iPhone 13 Pro", "Latest smartphone with advanced camera features"),
        ("Nike Running Shoes", "Professional running shoes for athletes"),
        ("Coffee Table", "Modern wooden coffee table for living room"),
        ("Python Programming Book", "Comprehensive guide to Python programming"),
        ("Lipstick Set", "Premium makeup collection with various shades")
    ]
    
    print("\nTest Predictions:")
    for product_name, description in test_products:
        result = classifier.predict(product_name, description)
        print(f"Product: {product_name}")
        print(f"Predicted Category: {result['predicted_category']}")
        print(f"Confidence: {result['confidence']:.4f}")
        print("-" * 50)

if __name__ == "__main__":
    main() 